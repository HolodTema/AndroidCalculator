package com.example.calculator;

import java.lang.Math;

public class Calculation {
    private String calcDivision(long num1, long num2) {
        //There are two numbers that number 1 divide number
        if (num2 != 0){
            return Long.toString(num1 / num2);
        }
        else{
            return "ОШИБКА";
        }
    }

    private String calcAddition(long num1, long num2) {
        if (Long.toString(num1 + num2).length()<=10){
            return Long.toString(num1 + num2);
        }
        else{
            return "ОШИБКА";
        }

    }

    private String calcSubtraction(long num1, long num2) {
        if (Long.toString(num1 - num2).length()<=10){
            return Long.toString(num1 - num2);
        }
        else{
            return "ОШИБКА";
        }
    }

    private String calcMultiplication(long num1, long num2) {
        if (Long.toString(num1 * num2).length()<=10){
            return Long.toString(num1 * num2);
        }
        else{
            return "ОШИБКА";
        }
    }

    private String calcPower(long num1, long num2) {
        double powerBase = (double) num1;
        double powerIndicator = (double) num2;
        long powerResult = (long) Math.pow(powerBase, powerIndicator);
        if (Long.toString(powerResult).length()<=10){
            return Long.toString(powerResult);
        }
        else{
            return "ОШИБКА";
        }
    }

    public String calculate(long num1, long num2, String operator) {
        String result = "0";
        if (operator.equals("//")){
            result = calcDivision(num1, num2);
        }
        if (operator.equals("+")){
            result = calcAddition(num1, num2);
        }
        if (operator.equals("-")){
            result = calcSubtraction(num1, num2);
        }
        if (operator.equals("*")){
            result = calcMultiplication(num1, num2);
        }
        if (operator.equals("^")){
            result = calcPower(num1, num2);
        }
        return result;
    }

}
