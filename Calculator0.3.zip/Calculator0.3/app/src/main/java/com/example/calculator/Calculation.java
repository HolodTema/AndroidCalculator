package com.example.calculator;

import java.lang.Math;
import java.math.MathContext;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public class Calculation {

    private String calcDivision(double num1, double num2) {
        if (num2 != 0.0){
            String result = Double.toString(num1/num2);
            if(result.endsWith(".0")){
                return result.substring(0,result.length()-2);
            }
            else{
                return result;
            }
        }
        else{
            return "ОШИБКА";
        }
    }

    private String calcAddition(double num1, double num2) {
        if (Double.toString(num1 + num2).length()<=10){
            String result = Double.toString(num1 + num2);
            if(result.endsWith(".0")){
                return result.substring(0,result.length()-2);
            }
            else{
                return result;
            }
        }
        else{
            return "ОШИБКА";
        }
    }

    private String calcSubtraction(double num1, double num2) {
        MathContext mc = new MathContext(9);
        BigDecimal bigNum1 = new BigDecimal(num1, mc);
        BigDecimal bigNum2 = new BigDecimal(num2, mc);
        double resultDouble = bigNum1.subtract(bigNum2).doubleValue();
        //if (Double.toString(result).length()<=10){
            String result = Double.toString(resultDouble);
            if(result.endsWith(".0")){
                return result.substring(0,result.length()-2);
            }
            else{
                return result;
            }
        //}
        //else{
            //return "ОШИБКА";
        //}
    }

    private String calcMultiplication(double num1, double num2) {
        if (Double.toString(num1 * num2).length()<=10){
            String result = Double.toString(num1 * num2);
            if(result.endsWith(".0")){
                return result.substring(0,result.length()-2);
            }
            else{
                return result;
            }
        }
        else{
            return "ОШИБКА";
        }
    }

    private String calcPower(double num1, double num2) {
        double powerResult = Math.pow(num1, num2);
        DecimalFormat decimalFormat = new DecimalFormat( "#.########" );
        //if (Double.toString(powerResult).length()<=10){
            String result = decimalFormat.format(powerResult);
            if (result.endsWith(".0")) {
                return result.substring(0,result.length()-2);
            }
            else{
                return result;
            }
        //}
        //else{
            //return "ОШИБКА";
        //}
    }

    public String calcRadix(double num){
        if(num>=0){
            double radixResult = Math.sqrt(num);
            DecimalFormat decimalFormat = new DecimalFormat( "#.########" );
            String result = decimalFormat.format(radixResult);
            if (result.endsWith(".0")) {
                return result.substring(0,result.length()-2);
            }
            else{
                return result;
            }
        }
        else{
            return "ОШИБКА";
        }
    }

    public String calculate(double num1, double num2, String operator) {
        String result = "0";
        if (operator.equals("/")){
            result = calcDivision(num1, num2);
        }
        if (operator.equals("+")){
            result = calcAddition(num1, num2);
        }
        if (operator.equals("-")){
            result = calcSubtraction(num1, num2);
        }
        if (operator.equals("*")){
            result = calcMultiplication(num1, num2);
        }
        if (operator.equals("^")){
            result = calcPower(num1, num2);
        }
        return result;
    }

}
