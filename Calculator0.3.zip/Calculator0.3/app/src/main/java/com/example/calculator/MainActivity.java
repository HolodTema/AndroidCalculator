package com.example.calculator;

//import com.example.calculator.Calculation
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textOutput;
    double value1, value2 = 0;
    boolean valueEnabled = false;
    boolean stringReplace = true;
    String operator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textOutput = findViewById(R.id.textOutput);
    }

    public void onClickButtonNum(View view) {
        Button buttonNum = (Button) view;
        String addNum = buttonNum.getText().toString();
        if (stringReplace){
            textOutputSetString(addNum);
            stringReplace = false;
        }
        else{
            if ( textOutputGetString().length()<10 ){
                if (textOutputGetString().equals("0")) {
                    textOutputSetString(addNum);
                } else {
                    textOutputSetString(textOutputGetString() + addNum);
                }
            }
        }
    }

    public void onClickButtonNum000(View view) {
        if (!(stringReplace) & !(textOutputGetString().equals("0"))){
            String resultCheck = textOutputGetString()+"000";
            if (resultCheck.length()<=10) {
                textOutputSetString(resultCheck);
            }
            else{
                if (resultCheck.length()-10==2) {
                    //we can print only one zero symbol
                    textOutputSetString( textOutputGetString() + "0" );
                }
                if (resultCheck.length()-10==1) {
                    //we can print only two zero symbols
                    textOutputSetString( textOutputGetString() + "00" );
                }
            }

        }
    }

    public void onClickButtonNumDat(View view){
        if (!textOutputGetString().contains(".")){ //if we do not have dat symbol in output text string
            if (stringReplace){
                if (textOutputGetString().equals("0")){
                    textOutputSetString("0.");
                    stringReplace = false;
                }

            } else {
                if ( textOutputGetString().length()<10 ){
                    textOutputSetString(textOutputGetString()+".");
                }
            }
        }
    }

    public void onClickButtonClear(View view) {
        textOutputSetString("0");
        resetVars();
    }

    public void onClickButtonRadix(View view) {
        if (!textOutputGetString().equals("ОШИБКА")){
            Calculation calc = new Calculation();
            String resultRadix = calc.calcRadix(Double.parseDouble(textOutputGetString()));
            textOutputSetString(resultRadix);
            if (textOutputGetString().equals("ОШИБКА")){
                resetVars();
            }
        }
    }

    public void onClickButtonEqually(View view) {
        if (valueEnabled){
            value2 = Double.parseDouble(textOutputGetString());
            Calculation calc = new Calculation();
            textOutputSetString( calc.calculate(value1, value2, operator) );
            resetVars();
        }
    }

    public void onClickButtonOperator(View view) {
        Button buttonOperator = (Button) view;
        if (valueEnabled){
            if(stringReplace){
                operator = buttonOperator.getText().toString();
            }
            else{
                value2 = Double.parseDouble(textOutputGetString());
                Calculation calc = new Calculation();
                textOutputSetString( calc.calculate(value1, value2, operator) );
                if (textOutputGetString().equals("ОШИБКА")){
                    resetVars();
                }
                else{
                    value1 = Double.parseDouble(textOutputGetString());
                    operator = buttonOperator.getText().toString();
                    value2 = 0; /////
                    stringReplace = true;
                }
            }
        }
        else{
            if (!textOutputGetString().equals("ОШИБКА")){
                value1 = Double.parseDouble(textOutputGetString());
                operator = buttonOperator.getText().toString();
                valueEnabled = true;
                stringReplace = true;
            }
        }
    }

    private String textOutputGetString(){
        return textOutput.getText().toString();
    }
    private void textOutputSetString(String newStr) {
        textOutput.setText(newStr);
    }
    private void resetVars(){
        value1 = 0;
        value2 = 0;
        operator = "";
        valueEnabled = false;
        stringReplace = true;
    }

}